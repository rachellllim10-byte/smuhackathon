function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function readAgnesToken() {
  return String(process.env.AGNES_API_KEY || process.env.AGNES_TOKEN || '')
    .trim()
    .replace(/^Bearer\s+/i, '');
}

function agnesApiBase() {
  const base = (process.env.AGNES_API_BASE || 'https://apihub.agnes-ai.com').replace(/\/$/, '');
  return base.endsWith('/v1') ? base : `${base}/v1`;
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function extractText(data) {
  return data.choices?.[0]?.message?.content || data.output_text || data.text || data.response || data.result || '';
}

async function callAgnes(url, apiKey, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${apiKey}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const raw = await res.text();
  if (!res.ok) throw new Error(raw.slice(0, 300));
  return safeJson(raw);
}

function chatBody(prompt, model) {
  return {
    model,
    temperature: 0.4,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: 'Return only valid JSON for a low-stimulation study break.' },
      { role: 'user', content: prompt },
    ],
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const apiKey = readAgnesToken();
  const apiBase = agnesApiBase();
  const textUrl = process.env.AGNES_TEXT_API_URL || `${apiBase}/chat/completions`;
  const textModel = process.env.AGNES_TEXT_MODEL || 'agnes-2.0-flash';

  if (!apiKey) return json(501, { error: 'Missing AGNES_API_KEY (or AGNES_TOKEN)' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  const topic = String(body.topic || 'quiet rain walk').slice(0, 120);
  const prompt = [
    'Generate a low-stimulation 2-minute break concept for a study app.',
    `Topic: ${topic}`,
    'Return JSON: {"title":"string","script":"string"}.',
    'No cliffhangers, no intense novelty, no addictive feed language.',
  ].join('\n');

  let scriptPayload = {
    title: topic,
    script: `Two-minute ${topic}: one slow establishing shot, one small sensory detail, one quiet ending. Keep brightness low and return when the timer ends.`,
  };

  try {
    const textData = await callAgnes(textUrl, apiKey, textUrl.includes('/chat/completions')
      ? chatBody(prompt, textModel)
      : { model: textModel, prompt, input: { topic, plan: body.plan || null }, response_format: 'json' });
    const maybeText = extractText(textData);
    scriptPayload = typeof maybeText === 'string' && maybeText.trim().startsWith('{')
      ? JSON.parse(maybeText)
      : { ...scriptPayload, script: maybeText || scriptPayload.script };
  } catch (error) {
    scriptPayload.warning = 'Text endpoint did not complete; using local calm-break fallback.';
  }

  return json(200, scriptPayload);
};
