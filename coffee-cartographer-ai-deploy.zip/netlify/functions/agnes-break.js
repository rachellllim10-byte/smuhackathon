function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function extractText(data) {
  return data.choices?.[0]?.message?.content || data.output_text || data.text || data.response || data.result || '';
}

function findImageUrl(value) {
  if (!value || typeof value !== 'object') return null;
  for (const key of ['imageUrl', 'image_url', 'image', 'url', 'assetUrl', 'asset_url']) {
    const found = value[key];
    if (typeof found === 'string' && /^https?:\/\//i.test(found)) return found;
    if (found && typeof found === 'object') {
      const nested = findImageUrl(found);
      if (nested) return nested;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const nested = findImageUrl(item);
      if (nested) return nested;
    }
  }
  for (const key of ['data', 'output', 'result', 'results', 'assets', 'files', 'media']) {
    const nested = findImageUrl(value[key]);
    if (nested) return nested;
  }
  return null;
}

function extractImageUrl(data) {
  return findImageUrl(data);
}

async function callAgnes(url, apiKey, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${apiKey}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  const raw = await res.text();
  if (!res.ok) throw new Error(raw.slice(0, 300));
  return safeJson(raw);
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const apiKey = process.env.AGNES_API_KEY;
  const textUrl = process.env.AGNES_TEXT_API_URL;
  const imageUrl = process.env.AGNES_IMAGE_API_URL;
  const textModel = process.env.AGNES_TEXT_MODEL || 'agnes-text-model-not-set';
  const imageModel = process.env.AGNES_IMAGE_MODEL || 'agnes-image-model-not-set';

  if (!apiKey) return json(501, { error: 'Missing AGNES_API_KEY' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  const topic = String(body.topic || 'quiet rain walk').slice(0, 120);
  const prompt = [
    'Generate a low-stimulation 2-minute break concept for a study app.',
    `Topic: ${topic}`,
    'Return JSON: {"title":"string","script":"string","imagePrompt":"string"}.',
    'No cliffhangers, no intense novelty, no addictive feed language.',
  ].join('\n');

  let scriptPayload = {
    title: topic,
    script: `Two-minute ${topic}: one slow establishing shot, one small sensory detail, one quiet ending. Keep brightness low and return when the timer ends.`,
    imagePrompt: `calm ${topic}, low stimulation, soft light, study break card`,
  };

  if (textUrl) {
    try {
      const textData = await callAgnes(textUrl, apiKey, {
        model: textModel,
        prompt,
        input: { topic, plan: body.plan || null },
        response_format: 'json',
      });
      const maybeText = extractText(textData);
      scriptPayload = typeof maybeText === 'string' && maybeText.trim().startsWith('{')
        ? JSON.parse(maybeText)
        : { ...scriptPayload, script: maybeText || scriptPayload.script };
    } catch (error) {
      scriptPayload.warning = 'Text endpoint did not complete; using local calm-break fallback.';
    }
  }

  if (imageUrl) {
    try {
      const imageData = await callAgnes(imageUrl, apiKey, {
        model: imageModel,
        prompt: scriptPayload.imagePrompt,
        input: { topic, style: 'low-stimulation study break visual' },
      });
      scriptPayload.imageUrl = extractImageUrl(imageData);
    } catch (error) {
      scriptPayload.imageWarning = 'Image endpoint did not complete.';
    }
  }

  return json(200, scriptPayload);
};
