function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function systemPrompt() {
  return [
    'You are Agnes, an impressive AI focus cartographer for a hackathon demo.',
    'You combine caffeine pharmacokinetics, sleep debt, stress, task timing, location context, and productivity planning.',
    'Return only valid JSON with this exact shape:',
    '{"headline":"string","reason":"string","nextAction":"string","steps":[["Analyst","string"],["Planner","string"],["Navigator","string"],["Guardrail","string"]]}',
    'Keep it specific, decisive, and demo-ready. Mention route/nearest coffee when location or mapsUrl is available.',
    'Do not give medical advice. Keep caffeine guidance conservative and sleep-protective.',
  ].join(' ');
}

function userPrompt(payload) {
  return [
    'Create a standout Agnes AI recommendation for this Coffee Cartographer AI payload.',
    'The user is likely a student or hackathon participant who needs a practical plan they can act on immediately.',
    '',
    JSON.stringify(payload, null, 2),
  ].join('\n');
}

function safeParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('Agnes did not return JSON');
    return JSON.parse(match[0]);
  }
}

function chatCompletionsBody(payload, model) {
  return {
    model,
    temperature: 0.5,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: systemPrompt() },
      { role: 'user', content: userPrompt(payload) },
    ],
  };
}

function genericBody(payload, model) {
  return {
    model,
    prompt: `${systemPrompt()}\n\n${userPrompt(payload)}`,
    input: payload,
    response_format: 'json',
  };
}

function extractPlan(raw) {
  const data = safeParseJson(raw);
  const content =
    data.choices?.[0]?.message?.content ||
    data.output_text ||
    data.text ||
    data.response ||
    data.result ||
    data.plan ||
    raw;
  return typeof content === 'string' ? safeParseJson(content) : content;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return json(405, { error: 'Use POST' });
  }

  const apiKey = process.env.AGNES_API_KEY;
  const apiUrl = process.env.AGNES_TEXT_API_URL;
  const model = process.env.AGNES_TEXT_MODEL || 'agnes-text-model-not-set';

  if (!apiKey) {
    return json(501, { error: 'Missing AGNES_API_KEY environment variable' });
  }
  if (!apiUrl) {
    return json(501, {
      error: 'Missing Agnes text endpoint',
      detail: 'Set AGNES_TEXT_API_URL in Netlify. This function does not use non-Agnes fallback models.',
    });
  }
  const apiStyle = process.env.AGNES_API_STYLE || (apiUrl.includes('/chat/completions') ? 'chat' : 'generic');

  let payload;
  try {
    payload = JSON.parse(event.body || '{}').payload;
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  if (!payload || typeof payload !== 'object') {
    return json(400, { error: 'Missing payload object' });
  }

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${apiKey}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify(apiStyle === 'chat' ? chatCompletionsBody(payload, model) : genericBody(payload, model)),
    });

    const raw = await response.text();
    if (!response.ok) {
      return json(response.status, { error: 'Agnes API request failed', detail: raw.slice(0, 500) });
    }

    return json(200, extractPlan(raw));
  } catch (error) {
    return json(500, { error: error.message || 'Agnes proxy failed' });
  }
};
