function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function readAgnesToken() {
  return String(process.env.AGNES_API_KEY || process.env.AGNES_TOKEN || '')
    .trim()
    .replace(/^Bearer\s+/i, '');
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 18000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function agnesApiBase() {
  const base = (process.env.AGNES_API_BASE || 'https://apihub.agnes-ai.com').replace(/\/$/, '');
  return base.endsWith('/v1') ? base : `${base}/v1`;
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function findMediaUrl(value, kind) {
  if (!value || typeof value !== 'object') return null;
  const directKeys = kind === 'video'
    ? ['videoUrl', 'video_url', 'video', 'url', 'assetUrl', 'asset_url']
    : ['url'];
  for (const key of directKeys) {
    const found = value[key];
    if (typeof found === 'string' && /^https?:\/\//i.test(found)) return found;
    if (found && typeof found === 'object') {
      const nested = findMediaUrl(found, kind);
      if (nested) return nested;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const nested = findMediaUrl(item, kind);
      if (nested) return nested;
    }
  }
  for (const key of ['data', 'output', 'result', 'results', 'assets', 'files', 'media']) {
    const nested = findMediaUrl(value[key], kind);
    if (nested) return nested;
  }
  return null;
}

function extractVideoUrl(data) {
  return findMediaUrl(data, 'video');
}

function extractTaskId(data) {
  return data.taskId || data.task_id || data.id || data.data?.taskId || data.data?.task_id || data.data?.id || data.output?.id || null;
}

function extractPollUrl(data) {
  return data.statusUrl || data.status_url || data.pollUrl || data.poll_url || data.pollingUrl || data.polling_url || null;
}

async function readJsonResponse(res) {
  const raw = await res.text();
  return { raw, data: safeJson(raw) };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const normalizedApiKey = readAgnesToken();
  const apiBase = agnesApiBase();
  const videoUrl = process.env.AGNES_VIDEO_API_URL || `${apiBase}/videos`;
  const videoModel = process.env.AGNES_VIDEO_MODEL || 'agnes-video-v2.0';

  if (!normalizedApiKey) return json(501, { error: 'Missing AGNES_API_KEY (or AGNES_TOKEN)' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  const topic = String(body.topic || 'quiet rain walk').slice(0, 120);
  const prompt = [
    `Generate a 2-minute low-stimulation break film: ${topic}.`,
    'Visual style: slow pacing, no fast cuts, no cliffhanger, no addictive feed pattern.',
    'Purpose: reset attention during a study break, then return to work.',
  ].join(' ');

  try {
    const res = await fetchWithTimeout(videoUrl, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${normalizedApiKey}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: videoModel,
        prompt,
        width: 1152,
        height: 768,
        num_frames: 121,
        frame_rate: 24,
      }),
    });
    const { raw, data } = await readJsonResponse(res);
    if (!res.ok) return json(res.status, { error: 'Agnes video request failed', detail: raw.slice(0, 300) });
    return json(200, {
      videoUrl: extractVideoUrl(data),
      taskId: extractTaskId(data),
      pollUrl: extractPollUrl(data),
      pending: !extractVideoUrl(data),
      raw: extractVideoUrl(data) ? undefined : data,
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      return json(408, { error: 'Agnes video request timed out' });
    }
    return json(500, { error: error.message || 'Agnes video proxy failed' });
  }
};
