function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function findMediaUrl(value, kind) {
  if (!value || typeof value !== 'object') return null;
  const directKeys = kind === 'video'
    ? ['videoUrl', 'video_url', 'video', 'url', 'assetUrl', 'asset_url']
    : ['url'];
  for (const key of directKeys) {
    const found = value[key];
    if (typeof found === 'string' && /^https?:\/\//i.test(found)) return found;
    if (found && typeof found === 'object') {
      const nested = findMediaUrl(found, kind);
      if (nested) return nested;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const nested = findMediaUrl(item, kind);
      if (nested) return nested;
    }
  }
  for (const key of ['data', 'output', 'result', 'results', 'assets', 'files', 'media']) {
    const nested = findMediaUrl(value[key], kind);
    if (nested) return nested;
  }
  return null;
}

function extractVideoUrl(data) {
  return findMediaUrl(data, 'video');
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const apiKey = process.env.AGNES_API_KEY;
  const videoUrl = process.env.AGNES_VIDEO_API_URL;
  const videoModel = process.env.AGNES_VIDEO_MODEL || 'agnes-video-model-not-set';

  if (!apiKey) return json(501, { error: 'Missing AGNES_API_KEY' });
  if (!videoUrl) return json(501, { error: 'Missing AGNES_VIDEO_API_URL' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  const topic = String(body.topic || 'quiet rain walk').slice(0, 120);
  const prompt = [
    `Generate a 2-minute low-stimulation break film: ${topic}.`,
    'Visual style: slow pacing, no fast cuts, no cliffhanger, no addictive feed pattern.',
    'Purpose: reset attention during a study break, then return to work.',
  ].join(' ');

  try {
    const res = await fetch(videoUrl, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${apiKey}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: videoModel,
        prompt,
        input: { topic, plan: body.plan || null, durationSeconds: 120 },
      }),
    });
    const raw = await res.text();
    if (!res.ok) return json(res.status, { error: 'Agnes video request failed', detail: raw.slice(0, 300) });
    const data = safeJson(raw);
    return json(200, { videoUrl: extractVideoUrl(data), raw: extractVideoUrl(data) ? undefined : data });
  } catch (error) {
    return json(500, { error: error.message || 'Agnes video proxy failed' });
  }
};
