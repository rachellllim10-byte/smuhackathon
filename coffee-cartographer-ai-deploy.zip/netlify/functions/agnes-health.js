function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function agnesApiBase() {
  const base = (process.env.AGNES_API_BASE || 'https://apihub.agnes-ai.com').replace(/\/$/, '');
  return base.endsWith('/v1') ? base : `${base}/v1`;
}

function readAgnesToken() {
  return String(process.env.AGNES_API_KEY || process.env.AGNES_TOKEN || '')
    .trim()
    .replace(/^Bearer\s+/i, '');
}

exports.handler = async () => {
  const apiBase = agnesApiBase();
  const hasAgnesKey = Boolean(readAgnesToken());
  return json(200, {
    ok: true,
    hasAgnesKey,
    apiBase,
    hasTextEndpoint: true,
    hasImageEndpoint: true,
    hasVideoEndpoint: true,
    textModel: process.env.AGNES_TEXT_MODEL || 'agnes-2.0-flash',
    imageModel: process.env.AGNES_IMAGE_MODEL || 'agnes-image-2.1-flash',
    videoModel: process.env.AGNES_VIDEO_MODEL || 'agnes-video-v2.0',
  });
};
