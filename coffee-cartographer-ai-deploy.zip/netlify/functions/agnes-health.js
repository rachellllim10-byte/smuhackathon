function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

exports.handler = async () => {
  return json(200, {
    ok: true,
    hasAgnesKey: Boolean(process.env.AGNES_API_KEY),
    hasTextEndpoint: Boolean(process.env.AGNES_TEXT_API_URL),
    hasImageEndpoint: Boolean(process.env.AGNES_IMAGE_API_URL),
    hasVideoEndpoint: Boolean(process.env.AGNES_VIDEO_API_URL),
    hasVoiceEndpoint: Boolean(process.env.AGNES_VOICE_API_URL),
    textModel: process.env.AGNES_TEXT_MODEL || 'AGNES_TEXT_MODEL not set',
    imageModel: process.env.AGNES_IMAGE_MODEL || 'AGNES_IMAGE_MODEL not set',
    videoModel: process.env.AGNES_VIDEO_MODEL || 'AGNES_VIDEO_MODEL not set',
    voiceModel: process.env.AGNES_VOICE_MODEL || 'AGNES_VOICE_MODEL not set',
  });
};
