function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function readAgnesToken() {
  return String(process.env.AGNES_API_KEY || process.env.AGNES_TOKEN || '')
    .trim()
    .replace(/^Bearer\s+/i, '');
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function agnesApiBase() {
  const base = (process.env.AGNES_API_BASE || 'https://apihub.agnes-ai.com').replace(/\/$/, '');
  return base.endsWith('/v1') ? base : `${base}/v1`;
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function findMediaUrl(value) {
  if (!value || typeof value !== 'object') return null;
  for (const key of ['videoUrl', 'video_url', 'video', 'url', 'assetUrl', 'asset_url']) {
    const found = value[key];
    if (typeof found === 'string' && /^https?:\/\//i.test(found)) return found;
    if (found && typeof found === 'object') {
      const nested = findMediaUrl(found);
      if (nested) return nested;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const nested = findMediaUrl(item);
      if (nested) return nested;
    }
  }
  for (const key of ['data', 'output', 'result', 'results', 'assets', 'files', 'media']) {
    const nested = findMediaUrl(value[key]);
    if (nested) return nested;
  }
  return null;
}

function videoStatus(data) {
  return String(data.status || data.state || data.task_status || data.data?.status || '').toLowerCase();
}

function buildStatusUrl(taskId, pollUrl) {
  const apiBase = agnesApiBase();
  if (pollUrl) {
    const allowed = new URL(apiBase);
    const parsed = new URL(pollUrl, allowed.origin);
    if (parsed.origin !== allowed.origin) throw new Error('Poll URL origin is not Agnes API');
    return parsed.toString();
  }
  if (!taskId) throw new Error('Missing Agnes video task id');
  return `${apiBase}/videos/${encodeURIComponent(taskId)}`;
}

  exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const apiKey = readAgnesToken();
  if (!apiKey) return json(501, { error: 'Missing AGNES_API_KEY (or AGNES_TOKEN)' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  try {
    const statusUrl = buildStatusUrl(body.taskId, body.pollUrl);
    const res = await fetchWithTimeout(statusUrl, {
      method: 'GET',
      headers: { authorization: `Bearer ${apiKey}` },
    });
    const raw = await res.text();
    const data = safeJson(raw);
    if (!res.ok) return json(res.status, { error: 'Agnes video status request failed', detail: raw.slice(0, 300) });
    const status = videoStatus(data);
    const failed = ['failed', 'error', 'cancelled', 'canceled'].includes(status);
    return json(200, {
      videoUrl: findMediaUrl(data),
      status: status || undefined,
      pending: !findMediaUrl(data) && !failed,
      failed: failed || undefined,
      raw: findMediaUrl(data) ? undefined : data,
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      return json(408, { error: 'Agnes video status request timed out' });
    }
    return json(500, { error: error.message || 'Agnes video status proxy failed' });
  }
};
