function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
}

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

function findMediaUrl(value) {
  if (!value || typeof value !== 'object') return null;
  for (const key of ['audioUrl', 'audio_url', 'audio', 'url', 'assetUrl', 'asset_url']) {
    const found = value[key];
    if (typeof found === 'string' && /^https?:\/\//i.test(found)) return found;
    if (found && typeof found === 'object') {
      const nested = findMediaUrl(found);
      if (nested) return nested;
    }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const nested = findMediaUrl(item);
      if (nested) return nested;
    }
  }
  for (const key of ['data', 'output', 'result', 'results', 'assets', 'files', 'media']) {
    const nested = findMediaUrl(value[key]);
    if (nested) return nested;
  }
  return null;
}

function extractAudioUrl(data) {
  return findMediaUrl(data);
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Use POST' });

  const apiKey = process.env.AGNES_API_KEY;
  const voiceUrl = process.env.AGNES_VOICE_API_URL;
  const voiceModel = process.env.AGNES_VOICE_MODEL || 'agnes-voice-model-not-set';

  if (!apiKey) return json(501, { error: 'Missing AGNES_API_KEY' });
  if (!voiceUrl) return json(501, { error: 'Missing AGNES_VOICE_API_URL' });

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid JSON body' });
  }

  const text = String(body.text || 'Your focus session is ready. Start with one calm study block.').slice(0, 1000);

  try {
    const res = await fetch(voiceUrl, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${apiKey}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: voiceModel,
        text,
        input: { text },
      }),
    });
    const raw = await res.text();
    if (!res.ok) return json(res.status, { error: 'Agnes voice request failed', detail: raw.slice(0, 300) });
    const data = safeJson(raw);
    return json(200, { audioUrl: extractAudioUrl(data), raw: extractAudioUrl(data) ? undefined : data });
  } catch (error) {
    return json(500, { error: error.message || 'Agnes voice proxy failed' });
  }
};
