# Coffee Cartographer AI

Deploy this folder to Netlify.

For the fastest upload path, see `NETLIFY_UPLOAD_CHECKLIST.md`.

## Environment Variables

Set this in Netlify before judging:

- `AGNES_API_KEY`: your Agnes API key

The app defaults to the Agnes free-model setup from the integration guide:

- API base: `https://apihub.agnes-ai.com/v1`
- Text: `agnes-2.0-flash` at `/chat/completions`
- Image: `agnes-image-2.1-flash` at `/images/generations`
- Video: `agnes-video-v2.0` at `/videos`

The app accepts `AGNES_API_BASE` as either `https://apihub.agnes-ai.com` or `https://apihub.agnes-ai.com/v1`.

Optional overrides:

- `AGNES_API_BASE`
- `AGNES_TEXT_API_URL`
- `AGNES_TEXT_MODEL`
- `AGNES_IMAGE_API_URL`
- `AGNES_IMAGE_MODEL`
- `AGNES_VIDEO_API_URL`
- `AGNES_VIDEO_MODEL`

This project uses the three free Agnes model families provided in the guide: text, image, and video. It does not use non-Agnes fallback models for the judged pipeline.

## Demo Path

1. Open the app.
2. Click `Hackathon Mode`.
3. Click `Use Live Location`.
4. Show the `Agnes AI Recommendation` panel.
5. Show the embedded map in `Nearest Coffee Action`.
6. Show `Agnes Multimodal Pipeline`, `Focus Session`, and `Live Check-In`.

## Debug

After deploy, open `/api/agnes-health` on your Netlify URL.

- `hasAgnesKey: true` means the key reached the Netlify Function.
- `hasTextEndpoint: true` means the Agnes text default/override is available.
- `hasImageEndpoint: true` means the Agnes image default/override is available.
- `hasVideoEndpoint: true` means the Agnes video default/override is available.
- If the app shows `Agnes Agent` instead of `Live Agnes`, the demo still works, but the live API call did not complete.
