# Coffee Cartographer AI

Deploy this folder to Netlify.

For the fastest upload path, see `NETLIFY_UPLOAD_CHECKLIST.md`.

## Environment Variables

Set these in Netlify before judging:

- `AGNES_API_KEY`: your Agnes API key
- `AGNES_TEXT_API_URL`: the real Agnes text/planner endpoint
- `AGNES_TEXT_MODEL`: the Agnes text model name judges expect to see
- `AGNES_IMAGE_API_URL`: the real Agnes image endpoint, for the personal energy map and break card
- `AGNES_IMAGE_MODEL`: the Agnes image model name
- `AGNES_VIDEO_API_URL`: the real Agnes video endpoint, for 2-minute break films
- `AGNES_VIDEO_MODEL`: the Agnes video model name
- `AGNES_VOICE_API_URL`: the real Agnes voice/audio endpoint, if available
- `AGNES_VOICE_MODEL`: the Agnes voice/audio model name, if available
- `AGNES_API_STYLE`: set to `chat` only if the Agnes text endpoint uses a chat-completions-shaped body; otherwise use `generic`

This project does not use non-Agnes fallback models. If the Agnes endpoint is not configured, the UI clearly says the Agnes endpoint needs configuration.

## Demo Path

1. Open the app.
2. Click `Hackathon Mode`.
3. Click `Use Live Location`.
4. Show the `Agnes AI Recommendation` panel.
5. Show the embedded map in `Nearest Coffee Action`.
6. Show `Agnes Multimodal Pipeline`, `Focus Session`, and `Live Check-In`.

## Debug

After deploy, open `/api/agnes-health` on your Netlify URL.

- `hasAgnesKey: true` means the key reached the Netlify Function.
- `hasTextEndpoint: true` means the text planner endpoint is configured.
- `hasImageEndpoint: true` means the image endpoint is configured.
- `hasVideoEndpoint: true` means the video endpoint is configured.
- `hasVoiceEndpoint: true` means the voice endpoint is configured.
- If the app shows `Agnes Agent` instead of `Live Agnes`, the demo still works, but the live API call did not complete.
