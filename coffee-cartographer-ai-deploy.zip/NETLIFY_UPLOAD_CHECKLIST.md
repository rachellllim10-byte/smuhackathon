# Netlify Upload Checklist

## What to upload

Upload the whole `coffee-cartographer-ai-deploy` folder, or upload `coffee-cartographer-ai-deploy.zip`.

Do not upload only `index.html`, because the Agnes proxy needs:

- `netlify.toml`
- `netlify/functions/agnes-plan.js`
- `netlify/functions/agnes-health.js`
- `netlify/functions/agnes-break.js`
- `netlify/functions/agnes-video.js`
- `netlify/functions/agnes-voice.js`

## Fast path

1. Open your Netlify site dashboard.
2. Go to `Deploys`.
3. Drag `coffee-cartographer-ai-deploy.zip` into the deploy area, or use `Trigger deploy` if the site is connected to the folder.
4. Wait for `Published`.
5. Open the site.
6. Click `Hackathon Mode`.
7. Click `Use My Location`.
8. Demo `Agnes AI Recommendation`, the embedded map, `Agnes Multimodal Pipeline`, `Focus Session`, and `Live Check-In`.

## Environment variable

Set this in Netlify:

```text
AGNES_API_KEY
AGNES_TEXT_API_URL
AGNES_TEXT_MODEL
AGNES_IMAGE_API_URL
AGNES_IMAGE_MODEL
AGNES_VIDEO_API_URL
AGNES_VIDEO_MODEL
AGNES_VOICE_API_URL
AGNES_VOICE_MODEL
```

Keep the API key and endpoints in Netlify environment variables only. Do not paste secrets into `index.html`.

## Health check

Open:

```text
/api/agnes-health
```

If `hasAgnesKey` is `true`, Netlify sees the key.
