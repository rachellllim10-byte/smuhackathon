# Netlify Upload Checklist

## What to upload

Upload the whole `coffee-cartographer-ai-deploy` folder, or upload `coffee-cartographer-ai-deploy.zip`.

Do not upload only `index.html`, because the Agnes proxy needs:

- `netlify.toml`
- `netlify/functions/agnes-plan.js`
- `netlify/functions/agnes-health.js`
- `netlify/functions/agnes-break.js`
- `netlify/functions/agnes-video.js`
- `netlify/functions/agnes-video-status.js`

## Fast path for the full demo

Use Netlify CLI from inside the `coffee-cartographer-ai-deploy` folder so the functions are deployed too:

```bash
mkdir -p .npm-cache
NPM_CONFIG_CACHE="$PWD/.npm-cache" npx --yes --package netlify-cli netlify login
NPM_CONFIG_CACHE="$PWD/.npm-cache" npx --yes --package netlify-cli netlify link
NPM_CONFIG_CACHE="$PWD/.npm-cache" npx --yes --package netlify-cli netlify deploy --prod --dir . --functions netlify/functions
```

If the terminal says `Waiting for authorization`, approve the Netlify browser page it opened, then return to the terminal.

After deploy:

1. Open the site.
2. Click `Hackathon Mode`.
3. Click `Use My Location`.
4. Demo `Agnes AI Recommendation`, the embedded map, `Agnes Multimodal Pipeline`, `Focus Session`, and `Live Check-In`.

## Environment variable

Set this in Netlify:

```text
AGNES_API_KEY
```

Text, image, and video use Agnes defaults from the guide:

```text
AGNES_API_BASE=https://apihub.agnes-ai.com
AGNES_TEXT_MODEL=agnes-2.0-flash
AGNES_IMAGE_MODEL=agnes-image-2.1-flash
AGNES_VIDEO_MODEL=agnes-video-v2.0
```

The app also accepts `AGNES_API_BASE=https://apihub.agnes-ai.com/v1`, but the installed Agnes skill helpers use the no-`/v1` base and append `/v1` themselves.

`agnes-free-image` and `agnes-free-video` are Codex skill folder names, not Netlify environment variable names. You only need to add the uppercase `AGNES_*` variables above if Agnes changes defaults or if a judge asks to see them explicitly in Netlify.

Keep the API key in Netlify environment variables only. Do not paste secrets into `index.html`.

## Health check

Open:

```text
/api/agnes-health
```

If `hasAgnesKey` is `true`, Netlify sees the key.

## Video reality check

- Agnes video is async: the app creates a video task with `/api/agnes-video`, then polls `/api/agnes-video-status`.
- If video still does not appear, open Netlify `Functions` logs for `agnes-video` and `agnes-video-status` and check the exact Agnes response body.
